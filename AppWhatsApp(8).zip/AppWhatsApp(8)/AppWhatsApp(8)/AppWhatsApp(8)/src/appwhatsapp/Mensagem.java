package appwhatsapp;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Mensagem implements Serializable{

    SimpleDateFormat sdf = new SimpleDateFormat();
    //telefone do responsável pelo envio da mensagem
    private String emissor;
    //texto da mensagem
    private String texto;
    private String status;
    private String dataHora;

    public Mensagem(String emissor, String texto) {
        this.emissor = emissor;
        this.texto = texto;
        this.dataHora = sdf.format(Calendar.getInstance().getTime());
        this.status = "Enviado";
    }

    public Mensagem() {
    }

    public String getEmissor() {
        return emissor;
    }

    public String getTexto() {
        return texto;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        //FALTA A VALIDAÇÃO DO STATUS
        this.status = status;

    }

    public String getDataHora() {
        return dataHora;
    }

    @Override
    public String toString() {
        return emissor + " diz: \n"
                + texto + "\n"
                + status + " "
                + dataHora + "\n\n";
    }

}
